//
//  SignUpViewController.swift
//  FinalExam
//
//  Created by english on 2024-04-26.
//

import UIKit
import FirebaseAuth

class RegisterViewController: UIViewController {
    
    
    @IBOutlet weak var emailTxt: UITextField!
    
    @IBOutlet weak var passwordTxt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

 
    @IBAction func signUpBtnPressed(_ sender: UIButton) {
        if emailTxt.text != "" && passwordTxt.text != "" {
            Auth.auth().createUser(withEmail: emailTxt.text!, password: passwordTxt.text!){
                (auth, error) in
                if error != nil{
                    self.makeAlert(title: "error", message: error?.localizedDescription ?? "something went wrong")
                }else{
                    self.tabBarController?.selectedIndex = 1
                  
                }
            }
        }else{
            makeAlert(title: "missing", message: "email/password missing")
        }
     
        
    }
    
    func makeAlert(title: String, message: String){
        let alert = UIAlertController( title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        
        let okBtn = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil)
        alert.addAction(okBtn)
        self.present( alert, animated: true, completion: nil)
    }
    
}
