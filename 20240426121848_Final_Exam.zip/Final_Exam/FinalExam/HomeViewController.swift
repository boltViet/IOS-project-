//
//  HomeViewController.swift
//  FinalExam
//
//  Created by english on 2024-04-26.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseStorage

class HomeViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    
    
    @IBOutlet weak var tableView: UITableView!
    var userEmailArray = [String]()
    var userTitleArray = [String]()
    var userDescriptionArray = [String]()
    var userTimeArray = [String]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        tableView.dataSource = self
        tableView.delegate = self
        getDataFromFirestore()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        tableView.rowHeight = 400
        return userTimeArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! HomeViewCell
        
        cell.titleLbl.text = userTitleArray[indexPath.row]
        cell.descLbl.text = userDescriptionArray[indexPath.row]
        
        cell.DateLbl.text = userTimeArray[indexPath.row]
        return cell
    }
    
    
    func getDataFromFirestore() {
        guard let currentUser = Auth.auth().currentUser else {
            print("No logged-in user found.")
            return
        }
        
        let userEmail = currentUser.email ?? ""
        
        let firestoreDatabase = Firestore.firestore()
        firestoreDatabase.collection("ToDos")
            .whereField("postedBy", isEqualTo: userEmail) // Filter tasks by the current user.
            .order(by: "date", descending: true)
            .addSnapshotListener { (snapshot, error) in
                if let error = error {
                    print(error.localizedDescription)
                } else if let snapshot = snapshot, !snapshot.isEmpty {
                    self.userTitleArray.removeAll(keepingCapacity: false)
                    self.userDescriptionArray.removeAll(keepingCapacity: false)
                    self.userTimeArray.removeAll(keepingCapacity: false)
                    self.userEmailArray.removeAll(keepingCapacity: false)
                    
                    for document in snapshot.documents {
                        if let postedBy = document.get("postedBy") as? String {
                            self.userEmailArray.append(postedBy)
                        }
                        if let title = document.get("title") as? String {
                            self.userTitleArray.append(title)
                        }
                        if let description = document.get("description") as? String {
                            self.userDescriptionArray.append(description)
                        }
                        if let timeDate = document.get("date") as? Timestamp {
                            let date = Date(timeIntervalSince1970: TimeInterval(timeDate.seconds))
                            let dateFormatter = DateFormatter()
                            dateFormatter.timeZone = TimeZone(abbreviation: "UTC-4")
                            dateFormatter.dateFormat = "MMMM d, yyyy 'at' h:mm:ss a"
                            let formattedDate = dateFormatter.string(from: date)
                            self.userTimeArray.append(formattedDate)
                        }
                    }
                    self.tableView.reloadData()
                }
            }
    }
    
    
    
}
