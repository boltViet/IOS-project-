//
//  LoginViewController.swift
//  FinalExam
//
//  Created by english on 2024-04-26.
//

import UIKit
import FirebaseAuth

class LoginViewController: UIViewController {
    
    @IBOutlet weak var passwordTxt: UITextField!
    @IBOutlet weak var emailTxt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func btnLoginPressed(_ sender: UIButton) {
        if emailTxt.text != "" && passwordTxt.text != "" {
            Auth.auth().signIn(withEmail: emailTxt.text!, password: passwordTxt.text!){
                (auth, error) in
                if error != nil{
                    
                    //toast message
                    Toast.ok(view: self, title: "Oops", message: "Invalid username or password")
                    self.makeAlert(title: "error", message: error?.localizedDescription ?? "Something went wrong")
                }else{
                    self.performSegue(withIdentifier: "toHomePage", sender: nil)
                    
                                    print("Logged in successfully!!")
                                    self.makeAlert(title: "success", message:"Logged in successfully!")
                }
            }
        }else{
            makeAlert(title: "missing", message: "Email/password missing")
        }
    }
    
    func makeAlert(title: String, message: String){
        let alert = UIAlertController( title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        
        let okBtn = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil)
        alert.addAction(okBtn)
        self.present( alert, animated: true, completion: nil)
    }
    
}
