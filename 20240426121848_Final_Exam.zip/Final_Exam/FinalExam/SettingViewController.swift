//
//  SettingViewController.swift
//  FinalExam
//
//  Created by english on 2024-04-26.
//

import UIKit
import FirebaseAuth

class SettingViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func LogoutBtnPressed(_ sender: UIButton) {
        
        do{
            try Auth.auth().signOut()//firebase signout
            
        }catch{
            print("some error")
            performSegue(withIdentifier: "toLogin", sender: nil)
        }
        performSegue(withIdentifier: "toLogin", sender: nil)
    }
    
    
}
