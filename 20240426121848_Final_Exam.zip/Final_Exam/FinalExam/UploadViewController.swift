//
//  UploadViewController.swift
//  FinalExam
//
//  Created by english on 2024-04-26.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseStorage

class UploadViewController: UIViewController {
    

    @IBOutlet weak var titleText: UITextField!
    @IBOutlet weak var descriptionTxt: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func uploadBtnPressed(_ sender: UIButton) {
        let storage = Storage.storage()
        let reference = storage.reference()
        
        let mediaFolder = reference.child("task") //reference to the folder
        let firestoreDatabase = Firestore.firestore()
        var firestoreReference: DocumentReference? = nil
                            let post = [
                                "postedBy": Auth.auth().currentUser!.email!,
                                "title": self.titleText.text!,
                                "description": self.descriptionTxt.text!,
                                "date": FieldValue.serverTimestamp()
                            ] as [String:Any]
                            //upload the data to the firebase
                            firestoreReference = firestoreDatabase.collection("ToDos").addDocument(data: post, completion: {
                                (error) in
                                print ("firestore Reference")
                                if error != nil {
                                    self.makeAlert(title: "Error", message: error?.localizedDescription ?? " something went wrong")
                                }else{
                                    self.titleText.text = ""
                                    self.descriptionTxt.text = ""
                                    print("post uploaded successfully!")
                                    self.tabBarController?.selectedIndex = 0
                                }
                            })
           }
    
    //Alert Box
    func makeAlert(title: String, message: String){
        let alert = UIAlertController( title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        
        let okBtn = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil)
        alert.addAction(okBtn)
        self.present( alert, animated: true, completion: nil)
        
    }
                    }



        
    
